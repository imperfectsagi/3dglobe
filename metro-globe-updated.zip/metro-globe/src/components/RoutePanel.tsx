import { useEffect, useMemo, useState } from "react";
import { findRoute, stations, TIMING_MODEL_NOTE, type MetroStation, type RouteResult } from "../lib/metro-data";
import { formatKm, formatMinutes } from "../lib/format";
import { ClockIcon, InfoIcon, InterchangeIcon, SwapIcon } from "./icons";

interface RoutePanelProps {
  fromStation: MetroStation | null;
  toStation: MetroStation | null;
  onSetFrom: (s: MetroStation | null) => void;
  onSetTo: (s: MetroStation | null) => void;
  onRouteComputed: (route: RouteResult | null) => void;
}

type ActiveField = "from" | "to" | null;

export function RoutePanel({ fromStation, toStation, onSetFrom, onSetTo, onRouteComputed }: RoutePanelProps) {
  const [fromQuery, setFromQuery] = useState("");
  const [toQuery, setToQuery] = useState("");
  const [activeField, setActiveField] = useState<ActiveField>(null);

  const route = useMemo(() => {
    if (!fromStation || !toStation) return null;
    return findRoute(fromStation.id, toStation.id);
  }, [fromStation, toStation]);

  useEffect(() => {
    onRouteComputed(route);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [route]);

  const suggestions = useMemo(() => {
    const q = (activeField === "from" ? fromQuery : toQuery).trim().toLowerCase();
    if (!q) return [];
    return stations
      .filter((s) => s.name.toLowerCase().includes(q))
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, 8);
  }, [activeField, fromQuery, toQuery]);

  const pick = (s: MetroStation) => {
    if (activeField === "from") {
      onSetFrom(s);
      setFromQuery("");
    } else if (activeField === "to") {
      onSetTo(s);
      setToQuery("");
    }
    setActiveField(null);
  };

  const swap = () => {
    const f = fromStation;
    onSetFrom(toStation);
    onSetTo(f);
  };

  const clearRoute = () => {
    onSetFrom(null);
    onSetTo(null);
    setFromQuery("");
    setToQuery("");
    setActiveField(null);
  };

  const totalStops = route ? route.steps.length + 1 : 0;

  return (
    <div>
      <div className="route-inputs">
        <div className="route-field">
          <span className="route-dot from" aria-hidden="true" />
          <label className="sr-only" htmlFor="route-from-input">
            From station
          </label>
          <input
            id="route-from-input"
            placeholder="From station (e.g. Pratap Nagar)"
            aria-label="From station"
            value={activeField === "from" ? fromQuery : (fromStation?.name ?? "")}
            onFocus={() => {
              setActiveField("from");
              setFromQuery("");
            }}
            onChange={(e) => setFromQuery(e.target.value)}
          />
        </div>

        {activeField === "from" && suggestions.length > 0 && (
          <div className="route-suggestions" role="listbox" aria-label="From station suggestions">
            {suggestions.map((s) => (
              <button key={s.id} className="station-row" onClick={() => pick(s)} role="option" aria-selected="false">
                <span className="station-row-text">
                  <div className="station-row-name">{s.name}</div>
                </span>
              </button>
            ))}
          </div>
        )}

        <button className="swap-btn" onClick={swap} aria-label="Swap from and to stations" style={{ alignSelf: "center" }}>
          <SwapIcon />
        </button>

        <div className="route-field">
          <span className="route-dot to" aria-hidden="true" />
          <label className="sr-only" htmlFor="route-to-input">
            To station
          </label>
          <input
            id="route-to-input"
            placeholder="To station (e.g. Rajiv Chowk)"
            aria-label="To station"
            value={activeField === "to" ? toQuery : (toStation?.name ?? "")}
            onFocus={() => {
              setActiveField("to");
              setToQuery("");
            }}
            onChange={(e) => setToQuery(e.target.value)}
          />
        </div>

        {activeField === "to" && suggestions.length > 0 && (
          <div className="route-suggestions" role="listbox" aria-label="To station suggestions">
            {suggestions.map((s) => (
              <button key={s.id} className="station-row" onClick={() => pick(s)} role="option" aria-selected="false">
                <span className="station-row-text">
                  <div className="station-row-name">{s.name}</div>
                </span>
              </button>
            ))}
          </div>
        )}

        {(fromStation || toStation) && (
          <button type="button" className="clear-route-btn" onClick={clearRoute}>
            Reset / clear route
          </button>
        )}
      </div>

      {fromStation && toStation && fromStation.id === toStation.id && (
        <div className="empty-hint">Pick two different stations to plan a route.</div>
      )}

      {route && fromStation && toStation && (
        <>
          <div className="route-direction-header">
            <span className="route-direction-station">{fromStation.name}</span>
            <span className="route-arrow" aria-hidden="true">→</span>
            <span className="route-direction-station">{toStation.name}</span>
          </div>

          <div className="route-summary">
            <div>
              <div className="route-summary-time tabular">
                {formatMinutes(route.totalTimeMin)}
                <small>min</small>
              </div>
            </div>
            <div className="route-summary-meta">
              {formatKm(route.totalDistanceKm)} km · {totalStops} stops ·{" "}
              {route.interchangeCount === 0
                ? "no interchange"
                : `${route.interchangeCount} line change${route.interchangeCount > 1 ? "s" : ""}`}
            </div>
          </div>

          <div className="section-label">Lines used, in order</div>
          <div className="route-line-sequence">
            {route.lineSequence.map((line, i) => (
              <span key={`${line.id}-${i}`} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                {i > 0 && <span className="route-arrow" aria-hidden="true">→</span>}
                <span className="route-line-pill">
                  <span className="dot" style={{ background: line.color }} />
                  {line.name.replace(/\s*\(Line.*?\)/, "")}
                </span>
              </span>
            ))}
          </div>

          <div className="section-label">Station-by-station, in travel direction</div>
          <div className="route-steps">
            {route.steps.map((step, i) => (
              <div
                key={i}
                className="route-step"
                style={{ ["--line-color" as string]: step.line.color }}
              >
                <div className="route-step-station">
                  {i === 0 ? step.from.name : null}
                  {i === 0 && <br />}
                  {step.to.name}
                </div>
                <div className="route-step-meta tabular">
                  <ClockIcon /> {formatMinutes(step.timeMin)} min · {step.line.name.replace(/\s*\(Line.*?\)/, "")}
                </div>
                {step.isInterchangeHop && (
                  <div className="route-step-interchange">
                    <InterchangeIcon /> Change at {step.from.name}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="timing-note">
            <InfoIcon /> {TIMING_MODEL_NOTE}
          </div>
        </>
      )}

      {fromStation && toStation && fromStation.id !== toStation.id && !route && (
        <div className="empty-hint">No route found between these stations.</div>
      )}
    </div>
  );
}
